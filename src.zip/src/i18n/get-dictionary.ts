import type { Locale } from "@/src/i18n/i18n-config";

// We enumerate all dictionaries here for better linting and typescript support
// We also get the default import for cleaner types
const dictionaries = {
	en: () => import("@/messages/en-US.json").then((module) => module.default),
	pt: () => import("@/messages/pt-PT.json").then((module) => module.default),
};

export const getDictionary = async (locale: Locale) =>
	dictionaries[locale]?.() ?? dictionaries.en();
